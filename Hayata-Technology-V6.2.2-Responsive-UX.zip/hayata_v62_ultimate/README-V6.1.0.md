# Hayata Technology V6.1.0

Site vitrine statique en HTML5, CSS et JavaScript natif.

## Pages
- `index.html` — Accueil
- `a-propos.html` — À propos
- `services.html` — Services
- `connectivite.html` — Pôle Connectivité
- `contact.html` — Contact et devis
- `404.html` — Page introuvable

## Publication
Téléverser le contenu de cette archive à la racine publique du site. Les fichiers `.htaccess` et `_headers` sont des exemples de configuration ; leur prise en charge dépend de l'hébergeur. Vérifier les instructions de `GUIDE-DEPLOIEMENT-V6.md` avant publication.

## Formulaires
Par défaut, les formulaires ouvrent le logiciel de messagerie via `mailto:`. Pour un envoi automatique, configurer un endpoint HTTPS fiable et vérifier sa validation côté serveur, sa protection contre les abus et sa politique de confidentialité. Ne jamais mettre une clé secrète dans le JavaScript public.
