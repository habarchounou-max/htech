# Hayata Technology — Version 2

## Évolutions principales
- Nouvelle direction visuelle : contraste plus éditorial, palette bleu nuit/cyan plus maîtrisée, boutons plus lisibles et cartes plus raffinées.
- Hiérarchie renforcée du hero et de la typographie, espacements revus et mise en page mobile ajustée.
- Remplacement sur l’accueil des affirmations chiffrées non documentées (pourcentage de solutions, nombre de partenaires et certification) par des messages de méthode et de valeur sans chiffres invérifiables.
- Conservation de l’architecture HTML/CSS/JavaScript native et des cinq pages principales.
- Conservation des améliorations de formulaires, d’accessibilité et de documentation de la version précédente.

## Limites connues
- La version n’a pas été publiée en production.
- Les essais visuels multi-navigateurs, Lighthouse et les soumissions réelles de formulaire restent à effectuer.
- Les coordonnées, le domaine et les liens sociaux doivent être confirmés par le propriétaire.
