# Hayata Technology V6.2.1 — Impact & Conversion Experience

## Mise en route
1. Extraire l’archive en conservant l’arborescence.
2. Ouvrir `index.html` pour une première vérification locale.
3. Tester toutes les pages, le menu mobile, les CTA, les formulaires et Google Maps.
4. Publier le contenu du dossier à la racine du site après validation visuelle.

## Chiffres clés intégrés
- 150+ projets numériques réalisés
- 10K utilisateurs actifs sur les solutions développées
- 1,7K personnes formées
- 50 déploiements d’infrastructures réseau

## Important
Le formulaire ouvre le client de messagerie de l’utilisateur afin de finaliser l’envoi ; il ne transmet pas automatiquement les données à un serveur. Le site est statiquement vérifié, mais le rendu doit encore être contrôlé dans un navigateur réel sur mobile et ordinateur.
