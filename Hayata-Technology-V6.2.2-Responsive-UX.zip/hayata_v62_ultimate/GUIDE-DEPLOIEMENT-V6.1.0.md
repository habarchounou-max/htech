# Guide de déploiement — V6.1.0

## 1. Préparer
- Décompresser l'archive et téléverser **le contenu** dans la racine publique (souvent `public_html`, `www` ou `htdocs`).
- Conserver une copie de la version actuellement publiée pour permettre un retour arrière.
- Vérifier que `index.html` est bien à la racine et que les dossiers `assets/css`, `assets/js` et `assets/img` ont conservé leur structure.

## 2. Vérifications après publication
- Ouvrir les cinq pages principales sur ordinateur et téléphone.
- Tester la navigation, le menu déroulant au clic et au clavier, les liens de devis et la page 404.
- Contrôler le chargement des logos, images, polices et icônes.
- Vérifier le certificat HTTPS et les redirections HTTP vers HTTPS.
- Vérifier les en-têtes de sécurité dans la configuration effective du serveur ; `.htaccess` et `_headers` sont des exemples et ne sont pas pris en charge par tous les hébergeurs.
- Contrôler le domaine canonique, le sitemap et les métadonnées de partage social.

## 3. Formulaires
Le mode actuel `mailto:` ouvre l'application de messagerie de la personne et ne transmet pas le message de manière invisible ou automatique. Pour la réception côté serveur, configurer un endpoint HTTPS, tester les réponses d'erreur et de succès, appliquer validation et limitation de débit côté serveur, et ne jamais exposer de secret dans le JavaScript public.

## 4. Cache et retour arrière
Après une publication, vider le cache CDN/hébergeur si nécessaire. En cas de régression, restaurer l'archive précédente puis purger à nouveau le cache. N'appliquer une politique de cache longue aux fichiers HTML que si le processus de déploiement invalide correctement ce cache.
