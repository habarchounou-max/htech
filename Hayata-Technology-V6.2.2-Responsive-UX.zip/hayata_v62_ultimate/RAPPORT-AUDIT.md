# Rapport d’audit — Hayata Technology

## Périmètre
Inspection de l’archive source, des cinq pages principales, de `404.html`, des styles, scripts, images, manifeste, sitemap, robots.txt, `.htaccess`, `_headers` et de la documentation source.

## Constats
- Site statique HTML/CSS/JavaScript, avec identité technologique sombre, menu responsive, sections de services, pôle connectivité et deux formulaires.
- Google Fonts, Font Awesome et OpenStreetMap sont des dépendances distantes.
- Les formulaires utilisent `mailto:` par défaut. L’ancien code affichait une confirmation même après échec réseau d’un endpoint configuré ; corrigé dans cette livraison.
- Le domaine, les coordonnées et les profils sociaux figurent dans le code mais doivent être confirmés par le propriétaire.
- Les en-têtes HTTP effectifs dépendent de l’hébergement.

## Modifications
- Validation native, prévention des doubles soumissions, état d’attente et messages distincts pour endpoint configuré, fallback `mailto:` et erreur réseau.
- Suppression du faux succès après échec de transmission automatisée.
- Messages de formulaire exposés via `role=status` ou `role=alert`.
- Ajout de focus visible, prise en charge de `prefers-reduced-motion` et adaptation aux appareils tactiles.
- Mise en pause du rendu animé du globe lorsque l’onglet est masqué.
- Renforcement des directives dans `_headers` et ajout de documentation.

## Validation humaine requise
Confirmer domaine, coordonnées, horaires, comptes sociaux, droits des images, endpoint du formulaire et configuration de l’hébergement.
