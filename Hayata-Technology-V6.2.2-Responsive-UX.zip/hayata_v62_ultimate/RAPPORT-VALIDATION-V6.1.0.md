# Rapport de validation — Hayata Technology V6.1.0

## Résultats vérifiés pour cette archive
- 6 pages HTML contrôlées.
- Références locales absentes : 0.
- Identifiants HTML dupliqués : 0.
- `node --check` sur les deux scripts JavaScript : réussi.
- `manifest.webmanifest` : JSON valide.
- `sitemap.xml` : XML valide.
- Archive ZIP : test d'intégrité réussi.
- Fichiers inclus dans le paquet : 55.

## Contrôles de build
Les contrôles automatisés de cette livraison vérifient :
- intégrité de l'archive ZIP ;
- syntaxe JavaScript avec `node --check` ;
- validité du manifeste JSON et du sitemap XML ;
- références locales aux fichiers du site ;
- identifiants HTML dupliqués ;
- présence des pages principales et des documents de livraison.

## Correctifs prioritaires
- Gestion du menu déroulant unifiée et attributs ARIA synchronisés.
- Retrait du canvas décoratif et des éléments de curseur personnalisé hérités.
- Transparence visible sur le fonctionnement du formulaire en mode `mailto:`.
- Styles de focus et réduction des animations renforcés.

## Tests non revendiqués
Aucun score Lighthouse, test complet WCAG, test sur appareils réels, test d'envoi de formulaire, test DNS/TLS ou contrôle des en-têtes HTTP en production n'est revendiqué. Ces contrôles nécessitent un navigateur et/ou l'hébergement final.

## Avant la mise en ligne
1. Confirmer domaine, coordonnées et liens sociaux avec le client.
2. Déployer sur un environnement de préproduction et tester les cinq pages sur mobile et ordinateur.
3. Configurer un endpoint HTTPS pour la réception automatique des formulaires, si souhaité.
4. Vérifier HTTPS, en-têtes de sécurité, redirections, pages 404 et parcours de contact.
