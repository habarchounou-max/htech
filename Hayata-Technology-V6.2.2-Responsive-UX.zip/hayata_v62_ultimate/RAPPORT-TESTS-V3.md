# Rapport de contrôle — Signature Edition V3

## Contrôles effectués localement
- Archive source V2 extraite et utilisée comme base.
- Cinq pages principales et page 404 présentes.
- Vérification des références locales HTML : effectuée.
- Vérification des identifiants dupliqués : effectuée.
- Vérification syntaxique JavaScript via `node --check` : effectuée si Node.js disponible dans l’environnement.
- Archive de livraison : test d’intégrité ZIP effectué.

## Résultats détaillés
Les résultats calculés lors de la génération sont résumés dans le message de livraison. Ces contrôles ne remplacent pas les tests de navigateur.

## Non vérifié
- Tests de parcours dans un navigateur réel.
- Capture d’écran responsive aux largeurs 320, 375, 390, 768, 1024, 1440 et 1600 px.
- Lighthouse, LCP, INP et CLS sur l’URL de production.
- Contrôle manuel WCAG 2.2 AA.
- Compatibilité réelle Safari, Firefox, Chrome et Edge.
- Envoi de formulaire sur endpoint réel.
- En-têtes HTTP appliqués par l’hébergeur.
