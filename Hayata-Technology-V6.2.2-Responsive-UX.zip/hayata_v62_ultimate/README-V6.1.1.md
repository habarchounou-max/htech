# Hayata Technology V6.1.1 — Expert Client Experience

Cette livraison repart de V6.1.0 Client Experience et ajoute des visuels technologiques et l’intégration Google Maps.

## Lancer en local
Ouvrir `index.html` dans un navigateur ou servir le dossier via un serveur HTTP local. Les polices et icônes existantes continuent à utiliser leurs CDN habituels.

## Pages principales
- `index.html` : accueil et présentation des expertises
- `services.html` : catalogue des services
- `connectivite.html` : pôle Connectivité et Infrastructures
- `contact.html` : coordonnées, formulaires et Google Maps

## À vérifier avant publication
1. Vérifier l’affichage sur smartphone et ordinateur.
2. Confirmer que la carte pointe visuellement vers le siège exact.
3. Configurer un endpoint d’envoi si les formulaires doivent transmettre les demandes automatiquement.
