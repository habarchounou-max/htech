# Guide de déploiement

Pour la procédure de production à jour, consulter `DEPLOIEMENT-FINAL.md`.

Résumé : sauvegarder la version en ligne, confirmer domaine et coordonnées, publier le contenu de l'archive à la racine web, activer HTTPS, tester les cinq pages et la page 404, puis vérifier les formulaires, les en-têtes HTTP et les performances. Les fichiers `.htaccess` et `_headers` dépendent du fournisseur d'hébergement.
