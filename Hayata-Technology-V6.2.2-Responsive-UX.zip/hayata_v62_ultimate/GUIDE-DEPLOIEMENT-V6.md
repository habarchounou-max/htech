# Guide de livraison et déploiement — V6.0.0

## Contenu
Publier le contenu de cette archive dans la racine publique de l'hébergement (`public_html`, `www` ou répertoire équivalent). Ne pas publier le dossier parent `hayata_v6` comme niveau supplémentaire. Les pages principales sont `index.html`, `a-propos.html`, `services.html`, `connectivite.html`, `contact.html` et `404.html`.

## Avant ouverture au public
1. Confirmer que le domaine canonique `https://www.hayatatech.com` est bien le domaine de production retenu et que le DNS pointe vers l'hébergement.
2. Vérifier les numéros, emails, adresse, horaires, profils sociaux et mentions légales avec le client.
3. Activer HTTPS, redirection HTTP→HTTPS et une seule version canonique du domaine (avec ou sans www). Ajuster ensuite les URLs canoniques, `sitemap.xml`, `robots.txt` et données structurées si le domaine retenu change.
4. Tester les cinq pages sur téléphone et ordinateur, les menus, les liens d'ancrage, le bouton WhatsApp, les appels téléphoniques et les deux formulaires.
5. Sans `window.HAYATA_FORM_ENDPOINT`, le formulaire lance `mailto:` : le visiteur doit confirmer l'envoi dans son application de messagerie. Pour une réception garantie, configurer un endpoint HTTPS côté serveur ou un fournisseur de formulaires, avec validation serveur, anti-spam et politique de confidentialité adaptée.
6. Vérifier les en-têtes HTTP réels (CSP adaptée aux CDN utilisés, HSTS uniquement une fois HTTPS validé, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy`) et les journaux d'erreur. Le fichier `.htaccess` et `_headers` ne sont interprétés que par les hébergements compatibles.
7. Lancer un audit navigateur (Lighthouse/PageSpeed), vérifier les contrastes et l'accessibilité clavier, puis contrôler les logs 404 et les formulaires en environnement de production.
8. Conserver la version précédente pour un retour arrière immédiat.

## Vérifications automatiques effectuées lors de la préparation
- Intégrité ZIP, références locales statiques, doublons d'identifiants HTML, syntaxe JavaScript avec Node si disponible, JSON du manifeste, XML du sitemap et présence des nouvelles couches V6.

## Limites
Cette archive est préparée pour être déployée mais n'a pas été publiée sur le serveur du client. Aucun test visuel réel dans un navigateur, audit Lighthouse, test serveur des formulaires ou contrôle DNS/HTTPS n'est revendiqué par ce guide.
