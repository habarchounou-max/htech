# Hayata Technology V6.2.1 — Impact & Conversion Experience

## Chiffres communiqués par Hayata Technology
- **150+** projets numériques réalisés
- **10K** utilisateurs actifs sur les solutions développées
- **1,7K** personnes formées
- **50** déploiements d’infrastructures réseau

Les chiffres sont repris tels que communiqués. Aucun client, résultat, certification ou indicateur supplémentaire n’a été inventé.

## Améliorations de l’expérience utilisateur
- Mise en avant des quatre indicateurs sur l’accueil et dans la section « Notre impact ».
- Présentation sous forme de cartes responsive, avec hiérarchie visuelle plus claire.
- Ajout d’un parcours de demande de devis en trois étapes.
- Textes d’aide plus explicites dans le formulaire.
- CTA contextuels en bas des pages Services et Connectivité.
- Ajustements responsive et prise en compte de `prefers-reduced-motion`.
- Conservation des coordonnées existantes et du lien Google Maps.

## Limites connues
Le formulaire utilise toujours le comportement d’envoi existant via le client de messagerie. Aucun backend d’envoi n’a été créé. Les vérifications statiques ne remplacent pas des essais dans un navigateur réel.
