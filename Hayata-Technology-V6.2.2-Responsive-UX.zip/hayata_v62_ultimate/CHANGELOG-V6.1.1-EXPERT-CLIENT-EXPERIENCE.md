# Hayata Technology V6.1.1 — Expert Client Experience

## Objectif
Faire évoluer la V6.1.0 sans changer sa direction artistique de fond : accueil sombre, pages intérieures lumineuses, HTML/CSS/JavaScript statiques.

## Améliorations
- Ajout d’illustrations visuelles dédiées aux réseaux et infrastructures, à la cybersécurité, aux datacenters/cloud, aux télécommunications et au conseil.
- Images intégrées dans les cartes de services de l’accueil et de la page Services, avec attributs `alt`, chargement différé et décodage asynchrone.
- Images complémentaires sur le pôle Connectivité pour rendre les prestations plus concrètes et faciles à parcourir.
- Enrichissement visuel de la zone héro de l’accueil avec une image de datacenter, tout en conservant l’identité V6.1.
- Carte Google Maps intégrée sur Contact, avec accès direct à la fiche fournie et bouton d’itinéraire.
- Correction de l’orthographe de l’adresse « Route de l’Abattoir de Farcha ».
- Styles adaptatifs pour mobile, états de survol discrets et prise en compte de la réduction des animations.

## Limites à connaître
- Les images illustrent les domaines d’activité ; elles ne sont pas présentées comme des photographies vérifiées des installations de Hayata Technology.
- L’intégration Google Maps utilise la recherche par nom et adresse, avec un lien secondaire vers la fiche partagée. Le centrage visuel exact doit être confirmé après publication dans un navigateur réel.
- Aucun formulaire n’a été connecté à un serveur d’envoi : le mécanisme existant de V6.1 est conservé.
