# Rapport de contrôles — V4

## Contrôles statiques
- Pages principales et page 404 présentes.
- Références locales HTML inspectées.
- Identifiants HTML dupliqués recherchés.
- Syntaxe JavaScript contrôlée avec Node.js si disponible.
- Intégrité de l’archive ZIP contrôlée après création.

## Contrôles non équivalents à un test navigateur
Les contrôles statiques ne prouvent ni la qualité exacte du rendu visuel, ni le fonctionnement de chaque interaction sur un vrai appareil.

## À tester avant production
- Rendu mobile/tablette/desktop à 320, 375, 390, 768, 1024, 1440 et 1600 px.
- Navigation clavier et lecteurs d’écran.
- Lighthouse et Core Web Vitals sur le domaine publié.
- Compatibilité réelle des navigateurs ciblés.
- Soumission de formulaires avec endpoint réel.
- En-têtes HTTP, HTTPS, redirections et cache sur l’hébergement.
