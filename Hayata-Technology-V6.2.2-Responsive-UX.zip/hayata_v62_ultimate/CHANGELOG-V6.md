# Changelog — V6.0.0 Client Experience Edition

## Direction produit
- Nouvelle direction « editorial technology » : plus de contraste entre accueil premium sombre et pages intérieures lumineuses, hiérarchie plus claire et moins d'effets décoratifs.
- Navigation, boutons, cartes, formulaires, pied de page et espaces retravaillés via une couche CSS dédiée, sans migration de framework.
- Suppression sur l'accueil du préchargeur, du fond canvas animé et des éléments de curseur décoratif afin de réduire la distraction et le travail graphique continu.
- Ajout d'un lien d'évitement visible au clavier, de styles focus renforcés, d'une meilleure prise en compte de la réduction des animations et d'améliorations clavier du menu déroulant.
- Chargement différé et décodage asynchrone appliqués aux images de contenu non prioritaires.
- Ajout d'une couche JavaScript isolée et d'une feuille de style V6 afin de conserver la base existante et faciliter le retour arrière.
- Métadonnées Open Graph URL harmonisées avec les URL canoniques existantes.

## Ce qui reste volontairement inchangé
- Pages et informations de l'entreprise, coordonnées, identité/logo, services et liens existants.
- Stack statique HTML/CSS/JavaScript, sans dépendance de compilation ajoutée.
- Les formulaires n'affirment pas un envoi automatique si aucun endpoint n'est configuré : le mode de secours ouvre l'application de messagerie.
