# Hayata Technology V6.2 — Conversion Experience

Version statique prête pour prévisualisation et essais d’hébergement. Ouvrir `index.html` ou servir le dossier avec un serveur HTTP local. Conserver toute l’arborescence lors du transfert.

Consulter `RAPPORT-VALIDATION-V6.2.md` pour les contrôles statiques et leurs limites. Le formulaire n’envoie pas directement les données depuis le serveur : il ouvre l’application de messagerie pour confirmation.
