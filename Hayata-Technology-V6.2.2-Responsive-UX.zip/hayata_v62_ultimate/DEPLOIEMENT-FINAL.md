# Hayata Technology — guide de mise en production

## Contenu
Site vitrine statique en HTML5, CSS et JavaScript natif. Aucune compilation n'est requise. Publier le **contenu** de cette archive à la racine web publique du domaine, et non le dossier parent contenant l'archive.

## Procédure recommandée
1. Faire une sauvegarde du site actuellement publié.
2. Confirmer avec le propriétaire le domaine canonique, les coordonnées, l'adresse e-mail, les horaires, les réseaux sociaux et les droits d'utilisation des logos/photos.
3. Extraire l'archive et envoyer tous les fichiers, y compris les fichiers cachés `.htaccess` et `_headers` si l'hébergeur les prend en charge.
4. Choisir la configuration correspondant à l'hébergeur : `.htaccess` pour Apache compatible ; `_headers` pour les plateformes qui reconnaissent ce format. Ces fichiers ne sont pas universels et ne doivent pas être considérés comme appliqués sans vérification.
5. Activer HTTPS dans le panneau de l'hébergeur et configurer la redirection HTTP vers HTTPS au niveau du serveur ou de la plateforme.
6. Vérifier les cinq pages principales, le menu mobile, les liens, les images, la page 404 et le rendu sur téléphone.
7. Tester le formulaire. Par défaut, il ouvre l'application de messagerie du visiteur via `mailto:` ; cela ne garantit pas l'envoi du message. Pour un envoi automatisé, configurer un endpoint HTTPS et le tester réellement.
8. Vérifier les en-têtes HTTP, les redirections, la console du navigateur et les performances après publication.
9. Soumettre le sitemap aux outils pour webmasters seulement après confirmation du domaine officiel.

## Domaine et SEO
Le code actuel utilise `https://www.hayatatech.com` dans les URL canoniques, le sitemap, les robots et les métadonnées sociales. **Ce domaine doit être confirmé par le propriétaire avant publication.** Si le domaine réel diffère, remplacer toutes les occurrences dans les six pages HTML, `sitemap.xml` et `robots.txt`, puis tester les redirections entre variantes avec/sans `www`.

## Cache et mises à jour
Les ressources n'utilisent pas de noms de fichiers versionnés. La configuration de cache a donc été réglée sans directive `immutable` sur les ressources ordinaires afin de réduire le risque qu'un navigateur conserve indéfiniment une ancienne version. Après mise à jour, vider le cache CDN si nécessaire.

## Formulaires et données
- Sans endpoint, le formulaire ouvre un lien `mailto:` : l'utilisateur doit envoyer le message depuis son logiciel de messagerie.
- Avec un endpoint, configurer `window.HAYATA_FORM_ENDPOINT` avant `assets/js/main.js`, selon le contrat exact du fournisseur.
- Tester succès, erreur réseau, validation, double clic et affichage accessible du statut.
- Ne jamais intégrer de clé privée dans les fichiers JavaScript publics. Prévoir anti-spam, limitation de débit et règles de conservation des données côté service.

## Sécurité
Les en-têtes fournis sont des valeurs de départ. Vérifier leur présence sur le domaine déployé. Aucune Content Security Policy stricte n'est ajoutée car les sources distantes et le fournisseur de formulaire doivent d'abord être recensés et testés. Les fichiers `.htaccess` et `_headers` ne sont lus que par les plateformes qui les prennent en charge.

## Retour arrière
Conserver l'archive précédemment publiée et sa date de déploiement. En cas de régression, restaurer cette archive, purger le cache CDN et refaire les vérifications essentielles.
