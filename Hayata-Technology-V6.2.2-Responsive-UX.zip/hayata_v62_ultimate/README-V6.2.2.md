# Hayata Technology V6.2.2 — Responsive UX

- Extraire l’archive en conservant l’arborescence.
- Ouvrir `index.html` pour un aperçu local.
- Tester le menu au clavier et au tactile, la barre mobile de devis, les liens, les formulaires et la carte.
- Tester sur des largeurs de 320 px, 375 px, 768 px, 1024 px et écran large.
- Le formulaire ouvre le client de messagerie, sauf si `window.HAYATA_FORM_ENDPOINT` est configuré vers un endpoint réel.

Les chiffres intégrés sont : 150+ projets numériques réalisés, 10K utilisateurs actifs, 1,7K personnes formées et 50 déploiements d’infrastructures réseau.
