# Rapport de validation — V6.1.1 Expert Client Experience

## Contrôles réalisés
- Vérification statique des liens locaux et des images référencées dans les pages HTML.
- Vérification de la présence des boutons Google Maps et de l’itinéraire sur `contact.html`.
- Contrôle de syntaxe des fichiers JavaScript avec Node.js.
- Vérification de l’intégrité de l’archive ZIP après génération.

## Contrôles non réalisés
- Pas de test visuel complet dans un navigateur réel ou sur un appareil mobile physique.
- Pas de test Lighthouse, de performance réseau réelle, ni de vérification de la position exacte de l’iframe Google Maps sur le site publié.
- Pas de test d’envoi réel de formulaire : la configuration d’un endpoint serveur reste nécessaire pour un envoi automatisé.
