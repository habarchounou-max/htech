# Hayata Technology — Changelog V6.1.0

## Objectif
Affiner la V6 autour de trois priorités : interactions cohérentes, réduction du travail décoratif permanent et transparence des formulaires.

## Modifications
- Correction d'un conflit entre deux gestionnaires de clic du menu déroulant : le menu pouvait s'ouvrir puis se refermer immédiatement.
- Synchronisation de `aria-expanded` à l'ouverture et à la fermeture du menu déroulant, y compris lors d'un clic à l'extérieur.
- Suppression des éléments de curseur personnalisé et du canvas décoratif hérités de l'ancienne direction artistique, qui continuaient à déclencher des traitements JavaScript.
- Renforcement des indicateurs de focus clavier pour la navigation, les boutons et les onglets.
- Ajout d'une note visible sur le traitement des informations et le comportement de secours des formulaires.
- Consolidation des styles de réduction des animations.
- Mise à jour de la version du projet.

## Limites
Le formulaire reste dépendant de la configuration d'un endpoint HTTPS si un envoi direct est souhaité. Sans endpoint, le site utilise `mailto:` et le visiteur doit confirmer l'envoi dans son logiciel de messagerie. Aucun test d'envoi réel ni test navigateur sur l'hébergement n'est revendiqué.
