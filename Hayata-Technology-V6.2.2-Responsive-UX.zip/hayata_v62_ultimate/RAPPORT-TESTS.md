# Rapport de tests — Hayata Technology

Date : 17 octobre 2026.

| Contrôle | Résultat | Preuve / méthode | Limite |
|---|---|---|---|
| Archive source lisible et extraite | RÉUSSI | Liste ZIP et extraction locale | — |
| Cinq pages principales présentes | RÉUSSI | Les cinq fichiers HTML requis sont présents ; contrôle H1/titre effectué | Ne valide pas le rendu |
| Liens/ressources locales | RÉUSSI | Contrôle statique de href/src locaux sur six pages ; manquants : 0 | Ne teste pas les URL externes ni les chemins construits par JS |
| Syntaxe JavaScript | RÉUSSI | `node --check assets/js/main.js` | N’exécute pas le code dans un navigateur |
| Navigation réelle | NON TESTÉ | Aucun navigateur automatisé disponible dans cette exécution | Tester clavier et souris |
| Endpoint de formulaire | NON TESTÉ | Aucun endpoint configuré | Nécessite un test réel contrôlé |
| Fallback `mailto:` | CODE INSPECTÉ | Message explicite indiquant que l’utilisateur doit envoyer le courriel | Dépend du client de messagerie |
| Responsive multi-écrans | NON TESTÉ | Pas de captures multi-viewport produites | Tester 320 à 1600 px |
| Lighthouse / Core Web Vitals | NON TESTÉ | Aucun rapport Lighthouse généré | À faire sur l’URL publiée |
| Accessibilité manuelle WCAG | PARTIELLEMENT AMÉLIORÉ | Focus, reduced-motion, statuts de formulaire | Pas une déclaration de conformité WCAG |
| Compatibilité navigateurs | NON TESTÉ | Pas de test cross-browser exécuté | Chrome, Firefox, Safari, Edge |
| En-têtes de sécurité en production | NON TESTÉ | Fichiers de configuration préparés | Dépend du serveur |

## Conclusion
Livraison améliorée et documentée, mais pas certifiée prête en production sans tests navigateur, tests de soumission, validation des coordonnées et contrôle de l’hébergement. Les contrôles non réalisés ne sont pas déclarés réussis.
